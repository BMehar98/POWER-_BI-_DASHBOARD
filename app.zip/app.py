import os
import pandas as pd
import numpy as np
from flask import Flask, render_template, request
from sqlalchemy import create_engine
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib

# Use a non-interactive backend for matplotlib
matplotlib.use('Agg')

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URI', 'mysql+pymysql://root:root123@localhost/hierarchical_db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Connect to the database
engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])

def fetch_table_data(table_name):
    """Fetch data from the specified database table."""
    try:
        query = f"SELECT * FROM {table_name}"
        return pd.read_sql(query, engine)
    except Exception as e:
        print(f"Error fetching data from table {table_name}: {e}")
        return pd.DataFrame()

def preprocess_data(df, features, categorical_columns):
    """Preprocess data by encoding categorical features and scaling numeric data."""
    try:
        df = df[features]
        label_encoders = {}
        for col in categorical_columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            label_encoders[col] = le
        
        scaler = StandardScaler()
        scaled_data = scaler.fit_transform(df)
        return scaled_data, scaler, label_encoders
    except KeyError as e:
        print(f"Error in preprocessing: {e}")
        return None, None, None

def apply_clustering(data):
    """Apply clustering algorithms and return cluster labels and scores."""
    try:
        # Apply KMeans
        kmeans = KMeans(n_clusters=3, random_state=42)
        kmeans_clusters = kmeans.fit_predict(data)

        # Apply Gaussian Mixture Model
        gmm = GaussianMixture(n_components=3, random_state=42)
        gmm_clusters = gmm.fit_predict(data)

        # Silhouette Score
        sil_score_kmeans = silhouette_score(data, kmeans_clusters)
        sil_score_gmm = silhouette_score(data, gmm_clusters)

        return kmeans_clusters, gmm_clusters, sil_score_kmeans, sil_score_gmm
    except Exception as e:
        print(f"Error in clustering: {e}")
        return None, None, None, None

def visualize_clusters(data, clusters, filename):
    """Visualize clusters using PCA and save the plot to a file."""
    try:
        pca = PCA(n_components=2)
        pca_data = pca.fit_transform(data)
        
        plt.figure(figsize=(8, 6))
        sns.scatterplot(x=pca_data[:, 0], y=pca_data[:, 1], hue=clusters, palette="viridis", s=100, edgecolor='black')
        plt.title("Cluster Visualization")
        plt.savefig(filename)
        plt.close()
    except Exception as e:
        print(f"Error in visualization: {e}")

@app.route('/')
def index():
    """Render the index page."""
    return render_template('index.html')

@app.route('/run_clustering', methods=['POST'])
def run_clustering():
    """Handle clustering requests and render results."""
    table_name = request.form['table_name']
    
    # Fetch data from the database
    df = fetch_table_data(table_name)

    if df.empty:
        return "Error: Table not found or empty."

    # Define features and categorical columns
    features = ["customer_id", "kitchen_city", "order_total_amount"]
    categorical_columns = ["kitchen_city"]

    # Preprocess data
    scaled_data, scaler, label_encoders = preprocess_data(df, features, categorical_columns)

    if scaled_data is None:
        return "Error in preprocessing data."

    # Apply clustering
    kmeans_clusters, gmm_clusters, sil_score_kmeans, sil_score_gmm = apply_clustering(scaled_data)

    if kmeans_clusters is None:
        return "Error in clustering algorithms."

    # Add clusters to the dataframe
    df['KMeans_Cluster'] = kmeans_clusters
    df['GMM_Cluster'] = gmm_clusters

    # Visualize clusters
    plot_path = os.path.join('static', 'clusters.png')
    visualize_clusters(scaled_data, kmeans_clusters, plot_path)

    return render_template('results.html', 
                           kmeans_score=sil_score_kmeans, 
                           gmm_score=sil_score_gmm, 
                           image_path=plot_path)

if __name__ == '__main__':
    app.run(debug=True)
